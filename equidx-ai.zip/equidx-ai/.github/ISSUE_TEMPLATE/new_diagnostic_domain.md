---
name: New diagnostic domain
about: Propose adding a new AI diagnostic domain module (e.g. a new panel type)
title: "[AI Domain] "
labels: ai-engine
---

**Domain name**


**Synthetic data plan**
How will synthetic training data be generated for this domain? (No real
patient data may be used — see CONTRIBUTING.md.)

**Feature set**
What inputs does this domain model take?

**Output shape**
What findings + confidence scores will this domain return?

**Reference literature (optional, for realism of synthetic ranges only)**
