---
name: Feature request
about: Propose a new capability for EQUIDX AI
title: "[Feature] "
labels: enhancement
---

**Problem this solves**


**Proposed solution**


**Affected area(s)**
web / backend / ai-engine / biosensor-simulator / analytics / mobile-api / infrastructure / docs

**Alternatives considered**
