---
name: Bug report
about: Report a defect in EQUIDX AI
title: "[Bug] "
labels: bug
---

**Describe the bug**
A clear description of what's wrong.

**Service affected**
web / backend / ai-engine / biosensor-simulator / analytics / mobile-api / infrastructure / docs

**Steps to reproduce**
1.
2.

**Expected behavior**


**Environment**
- OS:
- Docker Compose version:
- Branch/commit:
