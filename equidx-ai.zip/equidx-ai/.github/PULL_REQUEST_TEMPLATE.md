## Summary

<!-- What does this PR change, and why? -->

## Type of change

- [ ] Bug fix
- [ ] New feature
- [ ] Breaking change
- [ ] Documentation
- [ ] Infrastructure / CI

## Checklist

- [ ] Tests added/updated and passing locally (`make test`)
- [ ] Linting passes (`make lint`)
- [ ] No real/PHI-like data introduced anywhere (synthetic only)
- [ ] Docs updated if behavior or setup changed
- [ ] Disclaimer/labeling preserved on any clinical-adjacent UI or output
