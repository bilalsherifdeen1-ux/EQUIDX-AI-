variable "environment" { type = string }
variable "cidr_block" { type = string }
variable "az_count" { type = number }
